let fr = 48
let pos1 = 0
let pos2 = 0
let mod1 = 0
let mod2 = 0
let col = 0
let r1 = 0
let r2 = 0
let r3 = 0 
let nbp1 = 255
let nbp2 = 255
let tPos1 = 0
let tPos2 = 0
function setup() {
  pos1 = random(1,499);
  pos2 = random(1,499)
  mod1 = random(-10,10)
  mod2 = random(-10,10)
  createCanvas(500, 500);
  background(220);
  frameRate(fr);
  
}

function setup2(){
  pos1 = random(1,499);
  pos2 = random(1,499)
  //mod1 = random(-10,10)
  //mod2 = random(-10,10)
}

function keyPressed(){
  r1 = random(0, 255)
  if (key === 'm'){
    r2 = random(0, 255)
  r3 = random(0, 255)
  fill(r1, r2, r3)
  }
  if (key === 's'){
    strokeWeight(10)
      for (let x = 0; x <= 10; x++){
      tPos1 = random(1,499)
      tPos2 = random(1,499)
      point(tPos1, tPos2)
 //   point(255,255)
    }
    strokeWeight(1)
  }
  //if (key === 't'){
  //  mod1 = random(-10,10);
  //  mod2 = random(-10,10)
  //}
}
function mouseClicked(){
  mod1 = random(-10,10);
  mod2 = random(-10,10)
}

function draw() {
  pos1 += mod1
  pos2 += mod2
  
  ellipse( pos1, pos2, 100 )
  
  if (pos1 >= 550){
    setup2()
  } else if (pos1 <= -50) {
    setup2()
  } else if (pos2 >= 550){
    setup2()
  } else if (pos2 <= -50){
    setup2()
  }
  else if (mouseIsPressed == true) {
    //if it's going too slow
    //setup()
    console.log('hi sigma')
  }
  
}