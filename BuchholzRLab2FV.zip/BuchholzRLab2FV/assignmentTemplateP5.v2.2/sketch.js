function setup() {
  createCanvas(400, 400);
  background(85);
  colorMode(RGB,255,255,255,1);
  //setup above
  
  //noFill();
  fill(0,200,140,0.3)
  stroke(0);
  bezier(325,65,100,100, 500,300,80,350);
  bezier(325,65,0,100,0,300,-100,200)
  bezier(325,65,0,324,-202,18,137,68)
  bezier(325,65,0,399,52,80,0,400)
  
  fill(190,50,0,0.7);
  curve(-300,300,30,50,160,150,300,-100)
  
  fill(0,130,130,1);
  ellipse(100,100,100,100);
  
  fill(190,50,0,0.7);
  curve(400,-100,30,50,160,150,-300,400);
  //top left planet above
  //big yellow below
  fill(255,190,0,1);
  ellipse(280,280,200,200)
  
  fill(255);
  noStroke();
  triangle(325,30,300,75,350,75)
  triangle(300,50,350,50,325,95);
  
  
}
