var fr = 24
var orb1 = 0
var orb2 = 0
var speed1 = 0
var speed2 = 0
var ins = false;
var testnum = 0;
function orbRun(){
  orb1 = random(1,499)
  orb2 = random(1,499)
}
function setup() {
  createCanvas(500,500);
  frameRate(fr);
  orbRun();
}

function mousePressed(){
      if(ins==true){
        testnum =testnum+ 1;
        orbRun();
       }
    }


function draw() {
    
    background(255);
    ellipse(orb1, orb2, 50, 50);
    point(mouseX, mouseY);

    ins = collidePointEllipse(mouseX, mouseY, orb1, orb2, 50, 50);
    text(testnum,50,50);
    

    print(testnum);
    print(ins);
}